#!/bin/bash
# Mini Operating System - Process Management & CPU Scheduling Simulator (menu driver)
cd "$(dirname "$0")" && make -s >/dev/null 2>&1 || { echo "Build failed - run 'make' to see errors"; exit 1; }
while true; do
  echo
  echo "=============================================="
  echo "  MINI OS: PROCESS MANAGEMENT & CPU SCHEDULER "
  echo "=============================================="
  echo " 1. OS environment analysis (ps/CPU/memory/users)"
  echo " 2. Process creation: fork() + exec() + wait()"
  echo " 3. Zombie & orphan process demo"
  echo " 4. IPC using Pipe"
  echo " 5. IPC using Shared Memory"
  echo " 6. Synchronization using Semaphores"
  echo " 7. Shared Memory vs Pipe comparison"
  echo " 8. CPU Scheduling (FCFS, SJF, Priority, RR)"
  echo " 0. Exit"
  read -rp "Enter choice: " c
  case $c in
    1) ./sysinfo.sh ;;
    2) ./fork_exec_demo ;;
    3) ./fork_exec_demo zombie; ./fork_exec_demo orphan ;;
    4) ./pipe_demo ;;
    5) ./shm_demo ;;
    6) ./sem_demo ;;
    7) ./ipc_compare ;;
    8) read -rp "Time quantum [2]: " q; ./scheduler sample_input.txt "${q:-2}" ;;
    0) echo "Bye"; exit 0 ;;
    *) echo "Invalid choice" ;;
  esac
done
