/* Module 3b: IPC using POSIX shared memory (shm_open + mmap) */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/wait.h>

typedef struct { int data[5]; long sum; char msg[64]; } Shared;

int main(void) {
    setvbuf(stdout, NULL, _IONBF, 0);
    const char *name = "/minios_shm";
    int fd = shm_open(name, O_CREAT | O_RDWR, 0666);
    if (fd < 0) { perror("shm_open"); return 1; }
    if (ftruncate(fd, sizeof(Shared)) < 0) { perror("ftruncate"); return 1; }
    Shared *sh = mmap(NULL, sizeof(Shared), PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
    if (sh == MAP_FAILED) { perror("mmap"); return 1; }

    for (int i = 0; i < 5; i++) sh->data[i] = (i + 1) * 10;
    strcpy(sh->msg, "data written by parent");
    printf("[Parent %d] wrote data {10,20,30,40,50} into shared memory\n", getpid());

    pid_t pid = fork();
    if (pid == 0) {
        printf("[Child  %d] read msg  : \"%s\"\n", getpid(), sh->msg);
        long s = 0;
        for (int i = 0; i < 5; i++) s += sh->data[i];
        sh->sum = s;
        printf("[Child  %d] computed sum=%ld and stored it in shared memory\n", getpid(), s);
        exit(0);
    }
    wait(NULL);
    printf("[Parent %d] read sum written by child = %ld\n", getpid(), sh->sum);

    munmap(sh, sizeof(Shared)); close(fd); shm_unlink(name);
    return 0;
}
