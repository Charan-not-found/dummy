/* Module 5: Shared memory vs Pipe - throughput comparison
   Shared memory is synchronised with 2 semaphores (producer-consumer). */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <semaphore.h>
#include <sys/mman.h>
#include <sys/wait.h>

#define TOTAL (16UL * 1024 * 1024)            /* 16 MB transferred each time */
typedef struct { sem_t empty, full; char data[65536]; } Shm;

static double now(void) {
    struct timespec t; clock_gettime(CLOCK_MONOTONIC, &t);
    return t.tv_sec + t.tv_nsec / 1e9;
}

static double bench_pipe(size_t chunk) {
    int fd[2]; if (pipe(fd) < 0) { perror("pipe"); exit(1); }
    char *buf = malloc(chunk); memset(buf, 'A', chunk);
    size_t n = TOTAL / chunk;
    double t0 = now();
    pid_t pid = fork();
    if (pid == 0) {
        close(fd[1]); size_t got = 0;
        while (got < n * chunk) { ssize_t r = read(fd[0], buf, chunk); if (r <= 0) break; got += r; }
        _exit(0);
    }
    close(fd[0]);
    for (size_t i = 0; i < n; i++) if (write(fd[1], buf, chunk) < 0) perror("write");
    close(fd[1]); waitpid(pid, NULL, 0);
    double t = now() - t0; free(buf); return t;
}

static double bench_shm(size_t chunk) {
    Shm *s = mmap(NULL, sizeof *s, PROT_READ | PROT_WRITE, MAP_SHARED | MAP_ANONYMOUS, -1, 0);
    sem_init(&s->empty, 1, 1); sem_init(&s->full, 1, 0);
    char *buf = malloc(chunk); memset(buf, 'A', chunk);
    size_t n = TOTAL / chunk;
    double t0 = now();
    pid_t pid = fork();
    if (pid == 0) {
        for (size_t i = 0; i < n; i++) { sem_wait(&s->full); memcpy(buf, s->data, chunk); sem_post(&s->empty); }
        _exit(0);
    }
    for (size_t i = 0; i < n; i++) { sem_wait(&s->empty); memcpy(s->data, buf, chunk); sem_post(&s->full); }
    waitpid(pid, NULL, 0);
    double t = now() - t0; free(buf); munmap(s, sizeof *s); return t;
}

int main(void) {
    size_t sizes[] = {64, 1024, 4096, 65536};
    printf("Transferring %lu MB between parent and child\n\n", TOTAL >> 20);
    printf("%-12s | %-22s | %-22s\n", "Chunk size", "PIPE  (time / MB/s)", "SHARED MEM (time / MB/s)");
    printf("-------------+------------------------+------------------------\n");
    for (int i = 0; i < 4; i++) {
        double tp = bench_pipe(sizes[i]), ts = bench_shm(sizes[i]);
        double mb = TOTAL / 1048576.0;
        printf("%-9zu B  | %7.3f s / %8.1f   | %7.3f s / %8.1f\n", sizes[i], tp, mb / tp, ts, mb / ts);
    }
    return 0;
}
