/* Module 2: Process creation with fork(), exec(), wait()
   Usage: ./fork_exec_demo            -> 3 children (2 use exec, 1 plain)
          ./fork_exec_demo zombie     -> demonstrates a zombie process
          ./fork_exec_demo orphan     -> demonstrates an orphan process   */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>

static void normal_demo(void) {
    printf("[Parent] PID=%d  PPID=%d\n", getpid(), getppid());
    for (int i = 0; i < 3; i++) {
        pid_t pid = fork();
        if (pid < 0) { perror("fork"); exit(1); }
        if (pid == 0) {                                   /* ---- child ---- */
            printf("[Child %d] PID=%d  PPID=%d\n", i + 1, getpid(), getppid());
            if (i == 0) execlp("date", "date", (char *)NULL);
            if (i == 1) execlp("ls", "ls", "-l", "--color=never", "/proc/self/fd", (char *)NULL);
            sleep(1);                                    /* child 3: plain work */
            printf("[Child 3] finished work, exiting with code 7\n");
            exit(7);
        }
        printf("[Parent] created child %d with PID=%d\n", i + 1, pid);
    }
    for (int i = 0; i < 3; i++) {
        int st; pid_t w = wait(&st);
        printf("[Parent] child PID=%d terminated, exit status=%d\n", w, WEXITSTATUS(st));
    }
    printf("[Parent] all children reaped.\n");
}

static void zombie_demo(void) {
    pid_t pid = fork();
    if (pid == 0) { printf("[Child] PID=%d exiting immediately\n", getpid()); exit(0); }
    printf("[Parent] PID=%d sleeping 2s WITHOUT calling wait()\n", getpid());
    sleep(2);
    char cmd[128];
    snprintf(cmd, sizeof cmd, "ps -o pid,ppid,stat,comm --ppid %d", getpid());
    if (system(cmd) < 0) perror("system");
    wait(NULL);
    printf("[Parent] wait() called -> zombie removed\n");
}

static void orphan_demo(void) {
    pid_t pid = fork();
    if (pid == 0) {
        printf("[Child] PID=%d, my parent is %d\n", getpid(), getppid());
        sleep(2);
        printf("[Child] after parent exit, my PPID is now %d (adopted by init/systemd)\n", getppid());
        exit(0);
    }
    sleep(1);
    printf("[Parent] exiting before child finishes\n");
    exit(0);
}

int main(int argc, char **argv) {
    setvbuf(stdout, NULL, _IONBF, 0);
    if (argc > 1 && !strcmp(argv[1], "zombie")) zombie_demo();
    else if (argc > 1 && !strcmp(argv[1], "orphan")) orphan_demo();
    else normal_demo();
    return 0;
}
