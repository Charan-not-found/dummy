#!/bin/bash
# Module 1: Operating System Environment Analysis
echo "=========== 1. OS / KERNEL INFORMATION ==========="
uname -a
[ -f /etc/os-release ] && grep PRETTY_NAME /etc/os-release
echo
echo "=========== 2. RUNNING PROCESSES (top 10 by CPU) ==========="
ps -eo pid,ppid,user,stat,%cpu,%mem,comm --sort=-%cpu | head -11
echo
echo "Total processes : $(ps -e --no-headers | wc -l)"
echo "Running (R)     : $(ps -eo stat --no-headers | grep -c '^R')"
echo "Sleeping (S/D)  : $(ps -eo stat --no-headers | grep -c '^[SD]')"
echo "Zombie (Z)      : $(ps -eo stat --no-headers | grep -c '^Z')"
echo
echo "=========== 3. CPU UTILIZATION ==========="
echo "CPU cores       : $(nproc)"
echo "Load average    : $(cut -d' ' -f1-3 /proc/loadavg)   (1, 5, 15 min)"
# CPU usage from two samples of /proc/stat
read -r _ u1 n1 s1 i1 w1 q1 sq1 _ < /proc/stat; sleep 1
read -r _ u2 n2 s2 i2 w2 q2 sq2 _ < /proc/stat
busy=$(( (u2+n2+s2+q2+sq2) - (u1+n1+s1+q1+sq1) ))
total=$(( busy + (i2+w2) - (i1+w1) ))
[ "$total" -gt 0 ] && echo "CPU utilization : $(( 100*busy/total )) %  (sampled over 1 s from /proc/stat)"
echo
echo "=========== 4. MEMORY UTILIZATION ==========="
free -h
awk '/MemTotal/{t=$2}/MemAvailable/{a=$2}END{printf "Memory in use  : %.1f %%\n",(t-a)*100/t}' /proc/meminfo
echo
echo "=========== 5. LOGGED-IN USERS ==========="
echo "Current user    : $(whoami)  (uid=$(id -u))"
who 2>/dev/null || echo "(no interactive login sessions listed)"
echo "Uptime          : $(uptime -p 2>/dev/null)"
