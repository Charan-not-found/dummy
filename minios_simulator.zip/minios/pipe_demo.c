/* Module 3a: IPC using pipes (two pipes = two-way communication) */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <unistd.h>
#include <sys/wait.h>

int main(void) {
    setvbuf(stdout, NULL, _IONBF, 0);
    int p2c[2], c2p[2];                      /* parent->child, child->parent */
    if (pipe(p2c) < 0 || pipe(c2p) < 0) { perror("pipe"); return 1; }

    pid_t pid = fork();
    if (pid < 0) { perror("fork"); return 1; }

    if (pid == 0) {                          /* CHILD: reads request, sends reply */
        close(p2c[1]); close(c2p[0]);
        char buf[128];
        ssize_t n = read(p2c[0], buf, sizeof buf - 1);
        buf[n] = '\0';
        printf("[Child  %d] received via pipe : \"%s\"\n", getpid(), buf);
        for (int i = 0; i < n; i++) buf[i] = toupper((unsigned char)buf[i]);
        if (write(c2p[1], buf, n) < 0) perror("write");
        close(p2c[0]); close(c2p[1]);
        exit(0);
    }
    /* PARENT */
    close(p2c[0]); close(c2p[1]);
    const char *msg = "hello from parent process";
    printf("[Parent %d] sending via pipe  : \"%s\"\n", getpid(), msg);
    if (write(p2c[1], msg, strlen(msg)) < 0) perror("write");
    close(p2c[1]);
    char reply[128];
    ssize_t n = read(c2p[0], reply, sizeof reply - 1);
    reply[n] = '\0';
    printf("[Parent %d] reply from child  : \"%s\"\n", getpid(), reply);
    close(c2p[0]);
    wait(NULL);
    return 0;
}
