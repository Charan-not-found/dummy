/* Module 6: CPU Scheduling Simulator - FCFS, SJF (non-preemptive),
   Priority (non-preemptive, lower number = higher priority), Round Robin.
   Usage: ./scheduler [input_file] [time_quantum]
   Input file format (one process per line):  PID  ArrivalTime  BurstTime  Priority */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAXP 20
#define MAXSEG 500
typedef struct { int pid, at, bt, pr, rem, ct, tat, wt, rt, done; } Proc;
typedef struct { int pid, s, e; } Seg;          /* one block of the Gantt chart (pid 0 = idle) */
typedef struct { char name[24]; double wt, tat, rt, util, thr; } Summary;

static Seg g[MAXSEG]; static int ng;
static Summary sum[4]; static int nsum;

static void addseg(int pid, int s, int e) {
    if (e <= s) return;
    if (ng && g[ng-1].pid == pid && g[ng-1].e == s) { g[ng-1].e = e; return; }
    g[ng].pid = pid; g[ng].s = s; g[ng].e = e; ng++;
}

static void report(const char *name, Proc *p, int n) {
    printf("\n================ %s ================\nGantt chart:\n", name);
    for (int i = 0; i < ng; i++) {
        char lab[8]; if (g[i].pid) sprintf(lab, "P%d", g[i].pid); else strcpy(lab, "IDLE");
        printf("| %-4s ", lab);
    }
    printf("|\n");
    for (int i = 0; i < ng; i++) printf("%-7d", g[i].s);
    printf("%d\n\n", g[ng-1].e);

    printf("PID  AT  BT  PR   CT  TAT   WT   RT\n");
    double wt = 0, tat = 0, rt = 0; int busy = 0;
    for (int i = 0; i < n; i++) {
        p[i].tat = p[i].ct - p[i].at; p[i].wt = p[i].tat - p[i].bt;
        printf("P%-3d %3d %3d %3d %4d %4d %4d %4d\n", p[i].pid, p[i].at, p[i].bt, p[i].pr,
               p[i].ct, p[i].tat, p[i].wt, p[i].rt);
        wt += p[i].wt; tat += p[i].tat; rt += p[i].rt; busy += p[i].bt;
    }
    int end = g[ng-1].e, start = g[0].s;
    double total = end - start;
    Summary *s = &sum[nsum++];
    strncpy(s->name, name, 23); s->name[23] = 0;
    s->wt = wt / n; s->tat = tat / n; s->rt = rt / n;
    s->util = 100.0 * busy / total; s->thr = n / total;
    printf("Avg WT=%.2f  Avg TAT=%.2f  Avg RT=%.2f  CPU util=%.1f%%  Throughput=%.3f proc/unit\n",
           s->wt, s->tat, s->rt, s->util, s->thr);
}

/* mode 0 = FCFS, 1 = SJF, 2 = Priority */
static void run_np(Proc *in, int n, int mode, const char *name) {
    Proc p[MAXP]; memcpy(p, in, sizeof(Proc) * n); ng = 0;
    int t = 0, done = 0;
    while (done < n) {
        int best = -1;
        for (int i = 0; i < n; i++) {
            if (p[i].done || p[i].at > t) continue;
            if (best < 0) { best = i; continue; }
            int ki = mode == 1 ? p[i].bt : mode == 2 ? p[i].pr : p[i].at;
            int kb = mode == 1 ? p[best].bt : mode == 2 ? p[best].pr : p[best].at;
            if (ki < kb || (ki == kb && p[i].at < p[best].at)) best = i;
        }
        if (best < 0) {                                   /* CPU idle until next arrival */
            int nx = 1 << 30;
            for (int i = 0; i < n; i++) if (!p[i].done && p[i].at < nx) nx = p[i].at;
            addseg(0, t, nx); t = nx; continue;
        }
        p[best].rt = t - p[best].at;
        addseg(p[best].pid, t, t + p[best].bt);
        t += p[best].bt; p[best].ct = t; p[best].done = 1; done++;
    }
    report(name, p, n);
}

static void run_rr(Proc *in, int n, int q) {
    Proc p[MAXP]; memcpy(p, in, sizeof(Proc) * n); ng = 0;
    static int queue[10000]; int head = 0, tail = 0, inq[MAXP] = {0};
    for (int i = 0; i < n; i++) { p[i].rem = p[i].bt; p[i].rt = -1; }
    int t = 0, done = 0;
    char name[32]; sprintf(name, "ROUND ROBIN (q=%d)", q);
    while (done < n) {
        for (int i = 0; i < n; i++) if (!inq[i] && p[i].at <= t) { queue[tail++] = i; inq[i] = 1; }
        if (head == tail) {                               /* idle */
            int nx = 1 << 30;
            for (int i = 0; i < n; i++) if (!inq[i] && p[i].at < nx) nx = p[i].at;
            addseg(0, t, nx); t = nx; continue;
        }
        int i = queue[head++];
        if (p[i].rt < 0) p[i].rt = t - p[i].at;
        int run = p[i].rem < q ? p[i].rem : q;
        addseg(p[i].pid, t, t + run); t += run; p[i].rem -= run;
        for (int j = 0; j < n; j++) if (!inq[j] && p[j].at <= t) { queue[tail++] = j; inq[j] = 1; }
        if (p[i].rem > 0) queue[tail++] = i; else { p[i].ct = t; done++; }
    }
    report(name, p, n);
}

static int cmp(const void *a, const void *b) {
    const Proc *x = a, *y = b;
    return x->at != y->at ? x->at - y->at : x->pid - y->pid;
}

int main(int argc, char **argv) {
    Proc p[MAXP]; int n = 0, q = argc > 2 ? atoi(argv[2]) : 2;
    if (argc > 1) {
        FILE *f = fopen(argv[1], "r");
        if (!f) { perror("input file"); return 1; }
        while (n < MAXP && fscanf(f, "%d %d %d %d", &p[n].pid, &p[n].at, &p[n].bt, &p[n].pr) == 4) n++;
        fclose(f);
    } else {                                              /* built-in sample workload */
        int d[][4] = {{1,0,5,3},{2,1,3,2},{3,2,8,1},{4,3,6,4}};
        n = 4; for (int i = 0; i < n; i++) { p[i].pid=d[i][0]; p[i].at=d[i][1]; p[i].bt=d[i][2]; p[i].pr=d[i][3]; }
    }
    if (n == 0 || q <= 0) { fprintf(stderr, "invalid input\n"); return 1; }
    for (int i = 0; i < n; i++) { p[i].done = 0; p[i].rem = p[i].bt; p[i].rt = 0; }
    qsort(p, n, sizeof(Proc), cmp);

    printf("Input workload (PR: lower number = higher priority)\nPID  AT  BT  PR\n");
    for (int i = 0; i < n; i++) printf("P%-3d %3d %3d %3d\n", p[i].pid, p[i].at, p[i].bt, p[i].pr);

    run_np(p, n, 0, "FCFS");
    run_np(p, n, 1, "SJF (non-preemptive)");
    run_np(p, n, 2, "PRIORITY (non-preempt.)");
    run_rr(p, n, q);

    printf("\n================ PERFORMANCE COMPARISON ================\n");
    printf("%-24s %8s %8s %8s %8s %10s\n", "Algorithm", "AvgWT", "AvgTAT", "AvgRT", "CPU%", "Throughput");
    for (int i = 0; i < nsum; i++)
        printf("%-24s %8.2f %8.2f %8.2f %8.1f %10.3f\n", sum[i].name, sum[i].wt, sum[i].tat, sum[i].rt, sum[i].util, sum[i].thr);
    return 0;
}
