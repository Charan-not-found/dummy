/* Module 4: Process synchronization using POSIX semaphores
   Two processes increment a shared counter N times each.
   Without semaphore -> race condition (lost updates)
   With    semaphore -> correct result 2*N                       */
#include <stdio.h>
#include <stdlib.h>
#include <sched.h>
#include <unistd.h>
#include <semaphore.h>
#include <sys/mman.h>
#include <sys/wait.h>

#define N 200000
typedef struct { sem_t mutex; volatile long counter; } Shared;

static void worker(Shared *s, int use_sem) {
    for (int i = 0; i < N; i++) {
        if (use_sem) sem_wait(&s->mutex);      /* P(): enter critical section */
        long tmp = s->counter;                 /* critical section: read-modify-write */
        if (i % 100 == 0) sched_yield();       /* lets the scheduler switch mid-update */
        s->counter = tmp + 1;
        if (use_sem) sem_post(&s->mutex);      /* V(): leave critical section */
    }
}

static void run(int use_sem) {
    Shared *s = mmap(NULL, sizeof *s, PROT_READ | PROT_WRITE,
                     MAP_SHARED | MAP_ANONYMOUS, -1, 0);
    sem_init(&s->mutex, 1, 1);                 /* pshared=1, initial value=1 (binary) */
    s->counter = 0;
    pid_t a = fork();
    if (a == 0) { worker(s, use_sem); _exit(0); }
    pid_t b = fork();
    if (b == 0) { worker(s, use_sem); _exit(0); }
    waitpid(a, NULL, 0); waitpid(b, NULL, 0);
    printf("%-18s expected=%d  actual=%ld  -> %s\n",
           use_sem ? "WITH semaphore:" : "WITHOUT semaphore:", 2 * N, s->counter,
           s->counter == 2 * N ? "CORRECT" : "RACE CONDITION (lost updates)");
    sem_destroy(&s->mutex); munmap(s, sizeof *s);
}

int main(void) {
    setvbuf(stdout, NULL, _IONBF, 0);
    run(0);
    run(1);
    return 0;
}
